--------2.5D Raycast "Wolfenstein" Engine-------- 

-----ABOUT-----
Developed by Conn Buranicz
Summer 2017
ANSI C, SDL2

Thank you for taking a look at this Tech Demo. I wanted to see if I could pull off creating
a legendary style engine like this. I hope to try a Sector-based Doom-like Engine next!

-----CONTROLS-----

--MOVEMENT--
W= Forward
A= StrafeLeft
S= StrafeRight
D= Backwards

Left Arrow = Rotate Left
Right Arrow = Rotate Right

--EXEC--
F3= Disable Fullscreen
F4= Enable Fullscreen
Esc = Quit Game

--DEBUG VISUALS--
1= Textured Walls
2= Solid Color Walls
3= Enable Lighting
4= Disable Lighting

--DEBUG MAP--
9= Draw Rays
0= Disable Draw Rays
M= View Game MAP--
N= Normal View


